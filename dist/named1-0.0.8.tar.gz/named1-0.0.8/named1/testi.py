import trio

class TaskCall:
    def __init__(self):
        self.queue = trio.create_memory_channel(0)
        self.done = None

    async def __call__(self, *args):
        assert not self.event
        self.args = args
        await trio.hazmat.wait_task_rescheduled(lambda: trio.hazmat.Abort.FAILED)
        self.event = trio.Event()
        return event.wait()

    async def __aenter__(self):
        self.ret = None
        await self.ret

    async def __aexit__(self, exc_type, exc_value, tb):


Sender:
    ret = await channel(1, 2, 3)

Receiver:
    for a, b, c in channel:
        # Do something
