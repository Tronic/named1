# Named1 DNS server

A very experimental DNS server with Redis caching.

Linux:

````
pip3 install git+https://github.com/Tronic/named1.git
sudo apt install redis
sudo python3 -m named1
````

MacOS

````
pip3 install git+https://github.com/Tronic/named1.git
brew install redis
python3 -m named1
````
