class WontResolve(LookupError): pass
